# Лицензия на документацию

Содержимое папок `docs/`, `defs/` и `research/` распространяется по лицензии
**Creative Commons Attribution 4.0 International (CC BY 4.0)**.

Можно копировать, распространять, переделывать и использовать в любых целях, в том числе коммерческих,
при условии указания авторства (ссылки на этот репозиторий) и указания, были ли внесены изменения.

Полный текст: https://creativecommons.org/licenses/by/4.0/legalcode.ru

Copyright (c) 2026 edc15m contributors
